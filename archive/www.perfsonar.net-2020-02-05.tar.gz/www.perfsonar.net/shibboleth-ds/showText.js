var request = null;

    function createRequest() {
                try {
                        request = new XMLHttpRequest();
                } catch (trymicrosoft) {
                        try {
                                request = new
    ActiveXObject("Msxml2.XMLHTTP");
                        } catch (othermicrosoft) {
                                try {
                                        request = new
    ActiveXObject("Microsoft.XMLHTTP");
                                } catch (failed) {
                                        request = null;
                                }
                        }
                }

                if (request == null )
                        alert("Error creating request object!");
        }

        function getTheFeed(url) {
                createRequest();
                //var url = "http://miles.internet2.edu/iam/www.internet2.edu/data.txt";

                request.open("GET", url, true);
                request.onreadystatechange = updatePage;
                request.send(null);
        }

        function updatePage() {
                if (request.readyState == 4 ) {
                       var data = "";
                       //if (request.status == 200 ) {
                                data = request.responseText;
                       //} 
                       
                       document.getElementById( "topNav"       ).innerHTML = data;
                       document.getElementById( "fatFooterNav" ).innerHTML = data;
                }
        }