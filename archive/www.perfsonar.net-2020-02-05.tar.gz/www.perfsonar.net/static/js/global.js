﻿$(function () {
    // runs init on document ready
    global.init();
});

//----------------------------- Global JS

var global = {
	// Define the responsive breakpoints
	// Documentation: https://github.com/ten1seven/jRespond
	jRes: jRespond([
		{
			label: 'mobile',
			enter: 0,
			exit: 640
		}, {
			label: 'largeView',
			enter: 641,
			exit: 99999
		}
	]),

    init: function() {
		global.topNav();
		global.signInOut();
		global.mobileHeader();
    },

    topNav: function() {
		$('#topNav ul').superfish({
			dropShadows: false
		});
    },

    signInOut: function() {
		var $container = $('.acctWrapper'),
			$signinOpenLink = $container.find('#signInOutOpen'),
			$signIn = $container.find('#accountSignIn'),
			$signInLink = $signIn.find('#signIn'),
			$headerBlock = $('#account'),
			$signOutLinks = $('#signOut, #mobileSignoutLink'),
			$signInLI = $('.signinLI'),
			$mobileSigninLink = $signInLI.find('#mobileSigninLink'),
			$signOutLI = $('.signoutLI'),
			$closeLink = $signIn.find('.closeSignin'),
			$shib_frame = null,
			first_load = true;

		// Large View button to open sign-in window
		$signinOpenLink.on('click', function(e) {
			e.preventDefault();
            //PROMISE: load all shib-ds scripts then wait till it finishes loading
            if (first_load) {
                $.when(
                    $.getScript( "/static/shib-ds/idpselect_config_embed.js" ),
                    $.getScript( "/static/shib-ds/json2-full.js" ),
                    $.getScript( "/static/shib-ds/typeahead-full-embed.js" ),
                    $.getScript( "/static/shib-ds/idpselect-full.js" ),
                    $.Deferred(function( deferred ){
                        $( deferred.resolve );
                    })
                ).done(function(){
                    //PROMISE: the scripts are all loaded
                    console.log("shib load scripts done");
                    first_load =false;
                });
            }
            
			$signIn.fadeIn('fast');

			// Mobile
			$mobileSigninLink
				.removeClass('closed')
				.addClass('open');
				
			
		});

		// Large view and mobile: sign into Internet2
		$signInLink.on('click', function(e) {
			e.preventDefault();

			$headerBlock
				.removeClass('stateSignedOut')
				.addClass('stateSignedIn');
			$signIn.fadeOut('fast');

			// Mobile
			$signInLI.css('display', 'none');
			$signOutLI.css('display', 'list-item');
		});

		// Large view and mobile: sign out
		$signOutLinks.on('click', function(e) {
			e.preventDefault();

			$headerBlock
				.removeClass('stateSignedIn')
				.addClass('stateSignedOut');

			// Mobile
			$mobileSigninLink
				.removeClass('open')
				.addClass('closed');
			$signOutLI.css('display', 'none');
			$signInLI.css('display', 'list-item');
		});

		// Close the sign-in modal without signing in
		$closeLink.on('click', function(e) {
			e.preventDefault();

			$signIn.fadeOut();

			// Mobile
			$mobileSigninLink
				.removeClass('open')
				.addClass('closed');
		});
    },
    
    mobileHeader: function() {
		var $header = $('header'),
			$menuLink = $header.find('#menuLink'),
			$searchLink = $header.find('#searchLink'),
			$accountLink = $header.find('#mobileSigninLink'),
			$mobileMenu = $header.find('#mobileMenu'),
			$search = $header.find('#search'),
			$account = $header.find('#accountSignIn'),

			open = function($link, $section) {
				$link
					.removeClass('closed')
					.addClass('open');
					
				$section.slideDown('fast');
			},

			close = function($link, $section) {
				$link
					.removeClass('open')
					.addClass('closed');
				$section.slideUp(150);
			},

			openMenu = function() {
				$menuLink
					.removeClass('closed')
					.addClass('open');
				$mobileMenu
					.removeClass('mobileClosed')
					.addClass('mobileOpen')
					.slideDown('fast');
			},

			closeMenu = function() {
				$menuLink
					.removeClass('open')
					.addClass('closed');
				$mobileMenu
					.removeClass('mobileOpen')
					.addClass('mobileClosed')
					.slideUp(150);
			};

		$menuLink.on('click', function(e) {
			e.preventDefault();

			if ($mobileMenu.hasClass('mobileClosed')) {
				openMenu();	
				close($searchLink, $search);
				close($accountLink, $account);

			} else if ($mobileMenu.hasClass('mobileOpen')) {
				closeMenu();
			}
		});
        
		$searchLink.on('click', function(e) {
			e.preventDefault();

			if ($searchLink.hasClass('closed')) {
				open($searchLink, $search);	
				closeMenu();
				close($accountLink, $account);

			} else if ($searchLink.hasClass('open')) {
				close($searchLink, $search);
			}
		});
        /*
		$accountLink.on('click', function(e) {
			e.preventDefault();

			if ($accountLink.hasClass('closed')) {
				open($accountLink, $account);
				closeMenu();
				close($searchLink, $search);

			} else if ($accountLink.hasClass('open')) {
				close($accountLink, $account);
			}
		});*/

		global.jRes.addFunc({
			breakpoint: 'largeView',
			enter: function() {
				var accountStyle = $account.attr('style'),
					accountOpen;

				if (accountStyle !== undefined) {
					accountOpen = accountStyle.indexOf('block') !== -1 ? true : false;
				} else {
					accountOpen = false;
				}

				// If search is open on mobile, remove its "open" styles when changing to large view
				$searchLink
					.removeClass('open')
					.addClass('closed');
				$search.removeAttr('style');

				// Change account link classes appropriately to reflect state of sign in box between mobile and large view
				if (accountOpen) {
					$accountLink
						.removeClass('closed')
						.addClass('open');
				} else {
					$accountLink
						.removeClass('open')
						.addClass('closed');
				}
			}
		});
    }
};