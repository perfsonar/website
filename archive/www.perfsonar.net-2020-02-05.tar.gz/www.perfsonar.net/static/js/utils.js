﻿// Utils are initialized in the footer of the templates on a by-need basis

/*-------------------------*\
        HOMEPAGE
\*-------------------------*/

//----------------------------- Equal Heights Plugin

(function($) {
	$.fn.equalHeights = function(minHeight, maxHeight) {
		tallest = (minHeight) ? minHeight : 0;
		this.each(function() {
			$(this).height("auto");
		});
		this.each(function() {
			if ($(this).height() > tallest) {
				tallest = $(this).height();
			}
		});
		if ((maxHeight) && tallest > maxHeight) { tallest = maxHeight; }
		return this.each(function() {
			$(this).height(tallest);
		});
	};
})(jQuery);

//----------------------------- Homepage Basic Utils

var homeUtils = {

    init: function () {	
		var $win = $(window),
			$contentCols = $('.contentCol'),
			$featureCols = $('.feature'),

			eqCol = function() {

				if ($win.width() > 640) {
					setTimeout(function() { $contentCols.equalHeights(300); $featureCols.equalHeights(200); }, 250);
				}

				else {
					$contentCols.removeAttr('style');
				}
		};

		theater.init();
		eqCol();
		$win.on('resize', eqCol);
    }
};

//----------------------------- Homepage Theater

var theater = {

	$theater: $('#theater'),

	init: function() {
		// Enter large view: if slides aren't already present, load them and init flexslider
		// Enter mobile: (do nothing, just use CSS to replace theater section)
		global.jRes.addFunc({
			breakpoint: 'largeView',
			enter: function() {
				if (!$('#theaterList li').length) { 
					theater.loadSlides(); 
				}
			}
		});
	},

	loadSlides: function() {
		var $slidesList = $('#theaterList'),
			nSlides = $theaterSlidesObj.length,
			$statusList = $('#theaterStatus');

		// For every slide in the theaterSlidesObj:
		for (i = 0; i < nSlides; i++) {
			var $thisTheaterItem = $theaterSlidesObj[i],

				// Create theater slides
				$newSlideLI = $('<li/>'),
				$newSlideLink = $('<a/>').attr('href', $thisTheaterItem.anchor),
				$newSlideImg = $('<img/>')
									.attr('src', '' + $thisTheaterItem.img)
									.attr('alt', $thisTheaterItem.txt),

				// Create status flyout
				$newFlyoutLI = $('<li/>'),
				$newFlyoutImg = $('<img/>')
									.addClass('theaterThumb')
									.attr('src', '' + $thisTheaterItem.thumb),
				$newFlyoutText = $('<p><span class="theaterText">' + $thisTheaterItem.txt + '</span></p>');

			// If a video ID is present for this slide, add appropriate class and data attribute
			if ($thisTheaterItem.videoID !== '' && $thisTheaterItem.videoID !== undefined && $thisTheaterItem.videoID !== null) {
				$newSlideLink
					.addClass('lightBox')
					.attr('data-videoid', $thisTheaterItem.videoID)
					.attr('data-videotype', $thisTheaterItem.videoType);
			}

			// Append slides
			$newSlideLink.append($newSlideImg);
			$newSlideLI.append($newSlideLink);
			$slidesList.append($newSlideLI);

			// Append flyout data
			$newFlyoutLI.append($newFlyoutImg, $newFlyoutText);
			$statusList.append($newFlyoutLI);
		}

		// Initialize Flexslider once slides and status are loaded from array
		$('.flexslider').flexslider({
			directionNav: false,
			pauseOnHover: true,
			start: function(slider) {
				theater.flyout(slider);
			}
		});
	},

	flyout: function(slider) {
		var $controls = $('.flex-control-nav'),
			$a = $controls.find('a'),
			$flyout = $('#theaterFlyout'),

			showFlyout = function() {
				theater.$theater
					.removeClass('flyoutClosed')
					.addClass('flyoutOpen');
				$flyout.show();
			},

			hideFlyout = function() {
				theater.$theater
					.removeClass('flyoutOpen')
					.addClass('flyoutClosed');
				$flyout.hide();
			};

		$a.each(function(i) {
			var $this = $(this),
				$theaterStatusList = $('#theaterStatus'),
				$theaterStatusLIs = $theaterStatusList.find('li'),
				$thisFlyoutItem = $theaterStatusLIs.eq(i),
				$notThisItem = $theaterStatusLIs.not($thisFlyoutItem);

			$this
				.on('mouseenter', function() {
					$thisFlyoutItem.show();
					$notThisItem.hide();
					showFlyout();
				});

			$thisFlyoutItem.on('click', function() {
				slider.flexAnimate(i, true);
			});

		});	// end .each()

		$flyout.on('mouseleave', hideFlyout);
		theater.$theater.on('mouseleave', hideFlyout);

	}
};

/*-------------------------*\
		VIDEO UTILS
\*-------------------------*/

var video = {

    calculate: function ($video, $container) {
        var width = $video.width(),
            height = $video.height(),
            vidWidth = parseInt(width, 10),
            vidHeight = parseInt(width, 10) * 0.5625; /* Gets height based off the width and proportions of 16:9 video */

        if ($container !== null && $container !== undefined && $container !== '') {
            $container.css({
                marginTop: (-vidHeight / 2) + 'px',
                marginLeft: (-vidWidth / 2) + 'px'
            });
        }

        $video.height(vidHeight);
    },

    winResize: function ($video, $container) {
        $(window).on('resize', function () {
            video.calculate($video, $container);
        });
    },

    lightBoxVideo: function () {
        var $body = $('body'),
            $overlay = $('<div/>').addClass('overlay'),
            $container = $('<div/>').addClass('vidContainer'),
            $closeBtn = $('<a/>')
                            .addClass('close')
                            .attr('href', '#')
                            .html('Close'),

            closeHandler = function(e) {
                e.preventDefault();
                $closeBtn.trigger('closeVideo');
                $container.fadeOut();
                $overlay.fadeOut();
            };

        $overlay.on('click', closeHandler);

        $closeBtn
            .on('click', closeHandler)
            .appendTo($container);

        $('.lightBox').on('click', function(e) {
            var $embeddedSource = $(this).data('videoid');
            var $embeddedType   = $(this).data('videotype');

            var $video_elm = null;

            if ($embeddedType == "embedded") {
                $video_elm = $('<iframe/>', {
                                  width: '100%',
                                  height: '100%',
                                  src: '/video/'+$embeddedSource+'/embed',
                                  frameborder: 0,
                              })
            }

            $video_elm.addClass('vidLightBox');

            e.preventDefault();
        
            // If overlay not already present in the DOM, append overlay and container
            if (!$('.overlay').length) {
                $body.append($overlay, $container);
            // If already present, show
            } else {
                $overlay.show();
                $container.show();
            }

            // Append iframe to the video container and resize it appropriately
            $video_elm.appendTo($container);
            video.calculate($video_elm, $container);
            video.winResize($video_elm, $container);

            // Bind to close event to remove the iframe
            $closeBtn.on('closeVideo', function() {
                // remove everything after the first entry (i.e. everything
                // after the close button)
                $container.find('*:gt(0)').remove();

                $closeBtn.off('closeVideo');
            });

        }); // end lightbox on click
    },

    inlineVideo: function () {
		global.jRes.addFunc({
			breakpoint: 'largeView',
			exit: function() {
				video.replaceVideoLink();
			}
		});

        $('.inlineLink').on('click', function(e) {
            var $thisLink = $(this),
                $thisContainer = $thisLink.parent('.inlineContainer'),
                $thisImg = $thisContainer.find('img'),
                videoID = $thisLink.data('videoid'),
                $iframe = $('<iframe/>', {
                                src: '/video/'+videoID+'/embed',
                                frameborder: 0,
                                allowfullscreen: 1
                            }).addClass('inlineVid');

            e.preventDefault();

            $thisContainer.append($iframe);
            $thisLink.hide();

            video.calculate($iframe);
            video.winResize($iframe);
        });
    },

    replaceVideoLink: function() {
		// Remove video and replace it with the placeholder image when transitioning to mobile view if the "hideOnMobile" class is present on the video link
		var $videoLink = $('.inlineLink.hideOnMobile'),
			$inlineVid = $videoLink.next('iframe');

		$inlineVid.remove();
		$videoLink.removeAttr('style');
    }
};

/*-------------------------*\
	GENERAL SUBPAGE UTILS
\*-------------------------*/

var subUtils = {

	init: function() {
		var $win = $(window);

		subUtils.navCurrentLink();
		subUtils.setupHash();

		$win.on('hashchange', subUtils.hashHandler);
		$win.trigger('hashchange');
	},

	navCurrentLink: function() {
		// Dynamically adds a "current" class to current nav item LI and all parent LIs. Obviously, does not work if the URL is not in the nav!
		var path = window.location.pathname.split('/');

		path = path[path.length-1];

		if (path !== undefined) {
			$('ul.sf-menu, .channelNav ul, #mobileMenu')
				.find('a[href$="' + path + '"]')
				.parents('li')
				.addClass('current');
		}
    },

    setupHash: function() {
		// This initializes the hash and scrolls the page to the appropriate location so that the page doesn't jump weirdly during default behavior
		var $sectionLinks = $('.titleLink, .mobileTitle');

		$sectionLinks.on('click', function(e) {
			var $thisLink = $(this),
				thisHref = $thisLink.attr('href'),
				$htmlBody = $('html, body'),
				offset;

			e.preventDefault();

			// Scrolls the page if we're on mobile or IE7
			if ($thisLink.hasClass('mobileAcc') || $('html').hasClass('ie7')) {
				setTimeout(function() {
					$htmlBody.animate({
						scrollTop: $thisLink.offset().top
					}, 150);
				}, 100);
			}

			// Updates hash
			window.location.hash = thisHref;
		});
    },

    hashHandler: function() {
		// Enables hashchange events and permits linking directly to sections via hash
		var winWidth = $(window).width();
		var $body = $('body');
		var $channelContent = $( '#channelContent' );
		var hash = window.location.hash;

		// If there's a hash present, find the section that the hash
		// anchor is in, and set that to the active section ID. If no
		// hash, set active section to the first TOC item
		if (hash !== null && hash !== undefined && hash !== '' && hash !== '#') {
			activeSectionID = "#"+$(hash).closest('.tab-content').attr('id');
		}
		else {
			activeSectionID = $('#sectionTOC li:first-child').find('.titleLink').attr('href');
		}

		var	$activeLinks = $('a[href=' + activeSectionID + ']'),
			$inactiveLinks = $('.titleLink, .mobileAcc').not($activeLinks),
			$activeSection = $(activeSectionID),
			$inactiveSections = $('.section').not($activeSection);

		// Clear "current" classes from inactive sections and links
		$inactiveLinks.removeClass('current');
		$inactiveSections	
			.hide()
			.removeClass('current');

		// Add "current" classes to the active sections and links based on the current URL hash
		$activeLinks.addClass('current');
		$activeSection.addClass('current');

		if (winWidth > 640 || $body.hasClass('filterSubpage') ) {
			// Large view width (sections present as tabs)
			$activeSection.show();

		} else if (winWidth <= 640 && $body.hasClass('productSubpage')) {
			// Mobile width (sections present as accordions)
			$activeSection.slideDown('fast');
		} else if (winWidth <= 640 && $channelContent.hasClass('tabs')) {
			// Mobile width (sections present as accordions)
			$activeSection.slideDown('fast');
		}
		if (activeSectionID !== hash && $(hash).offset()) {
			$(document).scrollTop( $(hash).offset().top );
		}
    }
};

/*-------------------------*\
		FILTER SUB
\*-------------------------*/

var filterSubpage = {
	$win: $(window),
	$introCopy: $('.introCopy'),
	$vidContainer: $('.videoFootprint'),

	init: function() {
		filterSubpage.subnav();
		filterSubpage.responsiveFns();
	},

	responsiveFns: function() {
		var $filterDropdown = $('.filterDropdown'),
			$subnav = $('#channelNav'),
			subnavStyle = $subnav.attr('style'),
			$subnavLink = $('#mobileSubnavLink'),
			subnavOpen;

		if (subnavStyle !== undefined) {
			subnavOpen = subnavStyle.indexOf('block') !== -1 ? true : false;
		} else {
			subnavOpen = false;
		}

		global.jRes.addFunc({
			breakpoint: 'largeView',
			enter: function() {
				$filterDropdown.selectBox();
				// If subnav is open on mobile, remove its "open" styles when entering large view
				$subnavLink
					.removeClass('less')
					.addClass('more');
				$subnav.removeAttr('style');
			},
			exit: function() {
				$filterDropdown.selectBox('destroy');
			}
		});
	},

	subnav: function() {
		var $subnavLink = $('#mobileSubnavLink'),
			$nav = $('#channelNav');

		$subnavLink.on('click', function(e) {
			e.preventDefault();

			if ($subnavLink.hasClass('more')) {
				// open the nav
				$subnavLink
					.removeClass('more')
					.addClass('less');
				$nav.slideDown('fast');

			} else if ($subnavLink.hasClass('less')) {
				// close the nav
				$subnavLink
					.removeClass('less')
					.addClass('more');
				$nav.slideUp('fast');
			}
		});
	}
};


/* Ethos add remove utils */
var ethosUtils = {

    init: function () {	
		var $win = $(window),
			$contentCols = $('.contentCol'),
			                
			reqAddRemove = function($act, $sess, $user, $ethos) {
                var req = '/i/'+$act+'/'+$sess+'/'+$user+'/'+$ethos+'/'
                if (window.XMLHttpRequest) {
                    /* code for IE7+, Firefox, Chrome, Opera, Safari */
                    xmlhttp=new XMLHttpRequest();
                }
                else {
                    /* code for IE6, IE5 */
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                        var temp = '#addremove-'+$sess,
                            temp2 = temp+' span',
                            resp = xmlhttp.responseText;
                        $(temp2).text(resp);
                        
                        console.log(resp);
                        console.log(temp2);
                        if (resp === 'add') { 
                            /*add is in the responce */
                            $(temp).removeClass('remove')
    					            .addClass('add')
    					            .data("action", 'add')
    					            .attr("data-action", 'add');
    					}
    					else {
    					    $(temp).removeClass('add')
    					            .addClass('remove')
    					            .data("action", 'remove')
    					            .attr("data-action", 'remove');
    					}
    					
    					$('#addremove-10003226').addClass('test');
                    }
                }
                xmlhttp.open("GET", req ,true);
                xmlhttp.send();
		};
		
        $('.add-remove').on('click', function(e) {
            var $act = $(this).data('action');
            var $session_id   = $(this).data('sessionid');
            var $user_id = $(this).data('userid');
            var $ethos_id = $(this).data('ethosid');    
                
            reqAddRemove($act, $session_id, $user_id, $ethos_id);
            
            })
    }
};

/* Ethos quick view utils */
var quickview = {

    calculate: function ($video, $container) {
        var width = $video.width(),
            height = $video.height(),
            vidWidth = parseInt(width, 10),
            vidHeight = parseInt(width, 10) * 0.5625; /* Gets height based off the width and proportions of 16:9 video */

        if ($container !== null && $container !== undefined && $container !== '') {
            $container.css({
                marginTop: (-vidHeight / 2) + 'px',
                marginLeft: (-vidWidth / 2) + 'px'
            });
        }

        $video.height(vidHeight);
    },

    winResize: function ($video, $container) {
        $(window).on('resize', function () {
            quickview.calculate($video, $container);
        });
    },

    QuickView: function () {
        var $body = $('body'),
            $overlay = $('<div/>').addClass('overlay'),
            $container = $('<div/>').addClass('vidContainer'), /*qvContainer*/
            $closeBtn = $('<a/>')
                            .addClass('close')
                            .attr('href', '#')
                            .html('Close'),

            closeHandler = function(e) {
                e.preventDefault();
                $closeBtn.trigger('closeQV'); /* used to be closeVideo */
                $container.fadeOut();
                $overlay.fadeOut();
            };

        $overlay.on('click', closeHandler);

        $closeBtn
            .on('click', closeHandler)
            .appendTo($container);

        $('.quickview').on('click', function(e) {
            var $embeddedSource = $(this).data('sessionid');
            var $embeddedType   = $(this).data('sessiontype');

            var $video_elm = null;

            /* if ($embeddedType == "embedded") { */
                $video_elm = $('<iframe/>', {
                                  width: '100%',
                                  height: '100%',
                                  src: '/quickview/'+$embeddedSource+'/',
                                  frameborder: 0,
                              })
            /*} */

            $video_elm.addClass('vidLightBox');

            e.preventDefault();
        
            // If overlay not already present in the DOM, append overlay and container
            if (!$('.overlay').length) {
                $body.append($overlay, $container);
            // If already present, show
            } else {
                $overlay.show();
                $container.show();
            }

            // Append iframe to the video container and resize it appropriately
            $video_elm.appendTo($container);
            quickview.calculate($video_elm, $container);  /*used to be video. */
            quickview.winResize($video_elm, $container);  /*used to be video. */

            // Bind to close event to remove the iframe
            $closeBtn.on('closeQV', function() {
                // remove everything after the first entry (i.e. everything
                // after the close button)
                $container.find('*:gt(0)').remove();

                $closeBtn.off('closeQV');
            });

        }); // end lightbox on click
    },



    replaceVideoLink: function() {
		// Remove video and replace it with the placeholder image when transitioning to mobile view if the "hideOnMobile" class is present on the video link
		var $videoLink = $('.inlineLink.hideOnMobile'),
			$inlineVid = $videoLink.next('iframe');

		$inlineVid.remove();
		$videoLink.removeAttr('style');
    }
};

